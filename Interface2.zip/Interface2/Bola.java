public abstract class Bola {
    private String nomeDaMarca;
    
    public Bola(String nomeDaMarca){
        this.nomeDaMarca = nomeDaMarca;
    }

    public String getNomeDaMarca() {
        return nomeDaMarca;
    }

    public void setNomeDaMarca(String nomeDaMarca) {
        this.nomeDaMarca = nomeDaMarca;
    }

    public abstract void Quicar();
}
    