public class BolaDeBoliche extends Bola {

    public BolaDeBoliche(String nomeDaMarca) {
        super(nomeDaMarca);
        
    }
    
    public void Lancar(){
        System.out.println("A bola de boliche " +getNomeDaMarca()+ "e boa para ser lançada.");
    }

    public void Quicar(){
        System.out.println("A bola de boliche da " +getNomeDaMarca()+ " não são boas para quicar");
    }
    

}
