public class BolaDeFutbol extends Bola {

    public BolaDeFutbol(String nomeDaMarca) {
        super(nomeDaMarca);
        
    }

    public void Lancar(){
        System.out.println("A bola " +getNomeDaMarca()+ " e muito boa para chutar");
    }

    public void Quicar(){
        System.out.println("A bola da " +getNomeDaMarca()+ " quica muito!!");
    }
    

    
}
