public class TesteBolas implements Lancavel {
    public static void main(String args[]){
        Pedra pedregulho = new Pedra();
        pedregulho.lancar();

        BolaDeBoliche rhino= new BolaDeBoliche("SucaBullet");
        rhino.Lancar();
        rhino.Quicar();

        BolaDeFutbol jabulani = new BolaDeFutbol("Adidas");
        jabulani.Lancar();
        jabulani.Quicar();
    }
}